import sys
import urllib
import urlparse
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
import requests
import re
import CommonFunctions 
from bs4 import BeautifulSoup 
from lib import CMDTools

base_url = sys.argv[0]
web_name="THIENDIA"
web_url = "http://thiendia.com/" 

def get_Web_Name():
	return web_name
def get_img_thumb_url():
	return CMDTools.get_path_img('resources/media/xemvn.png')
    
def view():		
	addon_handle = int(sys.argv[1])
	addon       = xbmcaddon.Addon()
	addonname   = addon.getAddonInfo('name')
	
	args = urlparse.parse_qs(sys.argv[2][1:])

	xbmcplugin.setContent(addon_handle, 'movies')

	cat=args.get('cat', None)
	page = args.get('page', None)
	link = args.get('link', None)	
	show=args.get('show', None)	
	slideshow=args.get('slideshow', None)	
	
	catalogues=[{'label':'\xE1\xBA\xA2\x6E\x68\x20\x56\x69\xE1\xBB\x87\x74\x20\x4E\x61\x6D'.decode('utf-8'),'id':'http://thiendia.com/diendan/forumdisplay.php?f=28'},
				{'label':'\x4B\xC3\xAD\x20\x73\xE1\xBB\xB1\x20\x63\x68\x65\x63\x6B\x20\x68\xC3\xA0\x6E\x67\x20\x41\x43\x4D\x42'.decode('utf-8'),'id':'http://thiendia.com/diendan/forumdisplay.php?f=120'},
				{'label':'\x4E\xC3\xB4\x6E\x67\x20\x44\xC3\xA2\x6E\x20\x54\x72\xE1\xBB\x93\x6E\x67\x20\x72\x61\x75\x2C\x20\x48\xC3\xA1\x69\x20\x72\x61\x75\x20\x4D\x42'.decode('utf-8'),'id':'http://thiendia.com/diendan/forumdisplay.php?f=144'},
				{'label':'\xC4\x82\x6E\x20\x43\x68\xC6\xA1\x69\x20\x48\xE1\xBA\xA3\x69\x20\x50\x68\xC3\xB2\x6E\x67'.decode('utf-8'),'id':'http://thiendia.com/diendan/forumdisplay.php?f=143'},
				{'label':'\x47\xC3\xA1\x69\x20\x67\xE1\xBB\x8D\x69\x20\x4B\x68\x75\x20\x76\xE1\xBB\xB1\x63\x20\x6E\xE1\xBB\x99\x69\x20\x74\x68\xC3\xA0\x6E\x68\x20\x48\xC3\xA0\x20\x4E\xE1\xBB\x99\x69'.decode('utf-8'),'id':'http://thiendia.com/diendan/forumdisplay.php?f=193'},
				{'label':'\x4B\x68\x75\x20\x54\x72\xE1\xBA\xA7\x6E\x20\x44\x75\x79\x20\x48\xC6\xB0\x6E\x67\x2C\x20\x4E\x67\x75\x79\xE1\xBB\x85\x6E\x20\x54\x68\xE1\xBB\x8B\x20\xC4\x90\xE1\xBB\x8B\x6E\x68'.decode('utf-8'),'id':'http://thiendia.com/diendan/forumdisplay.php?f=194'},
				{'label':'\x43\xE1\xBA\xA7\x75\x20\x67\x69\xE1\xBA\xA5\x79\x2C\x20\x4E\x67\x75\x79\xE1\xBB\x85\x6E\x20\x4B\x68\xC3\xA1\x6E\x68\x20\x54\x6F\xC3\xA0\x6E\x2C\x20\x48\x51\x56'.decode('utf-8'),'id':'http://thiendia.com/diendan/forumdisplay.php?f=195'},
				{'label':'\x20\x4B\xC3\xAD\x20\x73\xE1\xBB\xB1\x20\x63\x68\x65\x63\x6B\x20\x68\xC3\xA0\x6E\x67\x20\x41\x43\x4D\x4E'.decode('utf-8'),'id':'http://thiendia.com/diendan/forumdisplay.php?f=125'},
				{'label':'\x4E\xC3\xB4\x6E\x67\x20\x44\xC3\xA2\x6E\x20\x54\x72\xE1\xBB\x93\x6E\x67\x20\x72\x61\x75\x2C\x20\x48\xC3\xA1\x69\x20\x72\x61\x75\x20\x4D\x4E'.decode('utf-8'),'id':'http://thiendia.com/diendan/forumdisplay.php?f=145'},
				{'label':'\x43\xE1\xBB\xA9\x75\x20\x6E\x65\x74\x20\x63\x68\x61\x74\x20\x73\x65\x78\x20\x6D\x69\xE1\xBB\x81\x6E\x20\x6E\x61\x6D'.decode('utf-8'),'id':'http://thiendia.com/diendan/forumdisplay.php?f=127'},
				{'label':'\xC4\x82\x6E\x20\x43\x68\xC6\xA1\x69\x20\x4D\x69\xE1\xBB\x81\x6E\x20\xC4\x90\xC3\xB4\x6E\x67'.decode('utf-8'),'id':'http://thiendia.com/diendan/forumdisplay.php?f=147'},
				{'label':'\xC4\x82\x6E\x20\x43\x68\xC6\xA1\x69\x20\x4D\x69\xE1\xBB\x81\x6E\x20\x54\xC3\xA2\x79'.decode('utf-8'),'id':'http://thiendia.com/diendan/forumdisplay.php?f=157'},
				{'label':'\x4B\xC3\xAD\x20\x73\xE1\xBB\xB1\x20\x63\x68\x65\x63\x6B\x20\x68\xC3\xA0\x6E\x67\x20\x41\x43\x4D\x54'.decode('utf-8'),'id':'\x4B\xC3\xAD\x20\x73\xE1\xBB\xB1\x20\x63\x68\x65\x63\x6B\x20\x68\xC3\xA0\x6E\x67\x20\x41\x43\x4D\x54'},
				{'label':'\x20\x4E\xC3\xB4\x6E\x67\x20\x44\xC3\xA2\x6E\x20\x54\x72\xE1\xBB\x93\x6E\x67\x20\x72\x61\x75\x2C\x20\x48\xC3\xA1\x69\x20\x72\x61\x75\x20\x4D\x54'.decode('utf-8'),'id':'http://thiendia.com/diendan/forumdisplay.php?f=185'},
				{'label':'\x4E\x68\xE1\xBA\xAD\x74\x20\x4B\xC3\xAD\x20\x4D\xC3\xA2\x79\x20\x4D\xC6\xB0\x61'.decode('utf-8'),'id':'http://thiendia.com/diendan/forumdisplay.php?f=82'},
				{'label':'\x48\xC3\xAC\x6E\x68\x20\x57\x65\x62\x63\x61\x6D\x20\x58\x58\x58\x20\x2D\x20\x43\x68\xE1\xBB\xA5\x70\x20\x6C\xC3\xA9\x6E\x20\x2D\x20\xE1\xBA\xA2\x6E\x68\x20\xC4\x91\xE1\xBB\x99\x63\x20\x53\x65\x78\x20\x56\x69\x65\x74\x20\x6E\x61\x6D'.decode('utf-8'),'id':'http://thiendia.com/diendan/forumdisplay.php?f=32'},
				{'label':''.decode('utf-8'),'id':''},
				{'label':''.decode('utf-8'),'id':''}]
	if show!=None:
		xbmc.executebuiltin("SlideShow(%s,recursive,notrandom)" % CMDTools.build_url(base_url,{'web':get_Web_Name(), 'slideshow':link[0]}))		
		#xbmc.executebuiltin('ShowPicture(%s)' % show[0])
		#play link
	if slideshow!=None:		
		r = requests.get(slideshow[0])
		html = r.text		
		#xbmc.log('----------------------------'+html.encode('utf-8'))
		common = CommonFunctions
		data=common.parseDOM(html, "div", attrs={'id':'posts'})		
		data=common.parseDOM(data, "td", attrs={'class':'alt1'})		
		posts=common.parseDOM(data[0], 'img', ret='src')
		xbmc.log('----------------------------'+str(posts))
		for item in posts:			
			li = xbmcgui.ListItem('')			
			li.setThumbnailImage(item)
			xbmcplugin.addDirectoryItem(handle=addon_handle, url=item, listitem=li)		
		return
	#play link
	if link!=None:	
		xbmc.executebuiltin("SlideShow(%s,recursive,notrandom)" % CMDTools.build_url(base_url,{'web':get_Web_Name(), 'slideshow':link[0]}))	
		#r = requests.get(link[0])
		#html = r.text		
		#soup = BeautifulSoup(html)
		#data_List=soup.findAll('img',attrs={'onload':'NcodeImageResizer.createOn(this);'})
		#for item in data_List:			
		#	li = xbmcgui.ListItem(item['alt'])			
		#	li.setThumbnailImage(item['src'])
		#	li_url=CMDTools.build_url(base_url,{'web':get_Web_Name(), 'link':link[0], #'show':item['src']})
		#	xbmcplugin.addDirectoryItem(handle=addon_handle, url=li_url, listitem=li)
		#xbmcplugin.endOfDirectory(addon_handle)			
		return
	#Load cats
	if cat==None:
		for cat in catalogues:
			li = xbmcgui.ListItem(cat['label'])
			urlList = CMDTools.build_url(base_url,{'web':get_Web_Name(), 'cat':cat['id']})
			xbmcplugin.addDirectoryItem(handle=addon_handle, url=urlList, listitem=li, isFolder=True)			
		return
	#Load noi dung cat
	if cat!=None:
		if page==None:
			page=1
		else:
			page=int(page[0])
		r = requests.get(cat[0]+"&page="+str(page))
		html = r.text				
		soup = BeautifulSoup(html) 
		#, convertEntities=BeautifulSoup.HTML_ENTITIES)			
		data_List=soup.findAll('a',attrs={'id':re.compile('thread_title')})		
		#load item menu
		for item in data_List:				
			link_item='http://thiendia.com/diendan/'+item['href']						
			li = xbmcgui.ListItem(item.string)						
			urlList = CMDTools.build_url(base_url,{'web':get_Web_Name(), 'link':link_item, 'type':cat[0]})
			xbmcplugin.addDirectoryItem(handle=addon_handle, url=urlList, listitem=li)			
		
		#Tao nut next	
		li = xbmcgui.ListItem("Next")	
		urlList=CMDTools.build_url(base_url,{'web':web_name, 'cat':cat[0],'page': page+1});
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=urlList, listitem=li, isFolder=True)		
		return